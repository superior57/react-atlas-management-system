import i18next from 'i18next';
import ar from './navigation-i18n/ar';
import en from './navigation-i18n/en';
import tr from './navigation-i18n/tr';

i18next.addResourceBundle('en', 'navigation', en);
i18next.addResourceBundle('tr', 'navigation', tr);
i18next.addResourceBundle('ar', 'navigation', ar);

const navigationConfig = [
	// {
	// 	id: 'applications',
	// 	title: 'Applications',
	// 	translate: 'APPLICATIONS',
	// 	type: 'group',
	// 	icon: 'apps',
	// 	children: [
			{
				id: "crew",
				title: 'Crew',
				translate: "CREW",
				type: "collapse",
				children: [
					{
						id: 'crew-new',
						title: 'New',
						translate: 'NEW',
						type: 'item',
						icon: 'whatshot',
						url: '/crew/new'
					},
					{
						id: 'crew-search',
						title: 'Search',
						translate: 'SEARCH',
						type: 'item',
						icon: 'whatshot',
						url: '/crew/search'
					},
					{
						id: 'crew-edit',
						title: 'Edit / View',
						translate: 'EDIT / VIEW',
						type: 'item',
						icon: 'whatshot',
						url: '/crew/details/1/personal-details'
					},
					{
						id: 'crew-list',
						title: 'List',
						translate: 'LIST',
						type: 'item',
						icon: 'whatshot',
						url: '/crew/list'
					},
					{
						id: 'crew-retention-rate',
						title: 'Retention Rate',
						translate: 'RETENTION RATE',
						type: 'item',
						icon: 'whatshot',
						url: '/crew/retention-rate'
					},
					{
						id: 'crew-wrh-list',
						title: 'WRH List',
						translate: 'WRH LIST',
						type: 'item',
						icon: 'whatshot',
						url: '/crew/wrh-list'
					},
					{
						id: 'crew-working-arrangements',
						title: 'Working Arrangements',
						translate: 'WORKING ARRAGEMENTS',
						type: 'item',
						icon: 'whatshot',
						url: '/crew/working-arrangements'
					}
				]
			},
			
	// 	]
	// }
];

export default navigationConfig;
