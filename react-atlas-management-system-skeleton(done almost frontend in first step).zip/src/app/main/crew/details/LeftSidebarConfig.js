const LeftSidebarConfig = [
    {
        title: "Personal Details",
        handle: 'personal-details'
    },
    {
        title: "Other Details",
        handle: 'other-details'
    },
    {
        title: "Certificates",
        handle: 'certificates'
    },
    {
        title: "Previous Services",
        handle: 'previous-services'
    },
    {
        title: "Company Previous Services",
        handle: 'company-previous-services'
    },
    {
        title: "Appraisals",
        handle: 'appraisals'
    },
    {
        title: "Next of KIN",
        handle: 'next-of-kin'
    },
    {
        title: "Allottees",
        handle: 'allottees'
    },
    {
        title: "Trainings",
        handle: 'trainings'
    }
];

export default LeftSidebarConfig;