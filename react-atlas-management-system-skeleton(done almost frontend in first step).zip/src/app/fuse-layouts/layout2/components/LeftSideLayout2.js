import React from 'react';

function LeftSideLayout2() {
	return <></>;
}

export default React.memo(LeftSideLayout2);
