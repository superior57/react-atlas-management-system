import FirebaseService from './firebaseService';

export default FirebaseService;
